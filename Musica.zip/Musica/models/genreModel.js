module.exports = (sequelize, DataTypes) => {
    const Genero = sequelize.define('Genero', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      nome: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
      },
    }, {
      tableName: 'generos', // Nome da tabela no banco de dados
      timestamps: false,
      freezeTableName: true,
    });
  
    Genero.associate = models => {
      Genero.hasMany(models.Artista, { foreignKey: 'genero_id', as: 'artistas' });
    };
  
    return Genero;
  };
  