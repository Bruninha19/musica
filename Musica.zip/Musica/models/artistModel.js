module.exports = (sequelize, DataTypes) => {
    const Artista = sequelize.define('Artista', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      nome: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      genero_id: {
        type: DataTypes.INTEGER,
        references: {
          model: 'generos',
          key: 'id',
        },
      },
    }, {
      tableName: 'artistas', // Nome da tabela no banco de dados
      timestamps: false,
      freezeTableName: true,
    });
  
    Artista.associate = models => {
      Artista.belongsTo(models.Genero, { foreignKey: 'genero_id', as: 'genero' });
      Artista.hasMany(models.Disco, { foreignKey: 'artista_id', as: 'discos' });
    };
  
    return Artista;
  };
  