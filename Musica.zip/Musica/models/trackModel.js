module.exports = (sequelize, DataTypes) => {
    const Faixa = sequelize.define('Faixa', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      titulo: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      disco_id: {
        type: DataTypes.INTEGER,
        references: {
          model: 'discos',
          key: 'id',
        },
      },
    }, {
      tableName: 'faixas', // Nome da tabela no banco de dados
      timestamps: false,
      freezeTableName: true,
    });
  
    Faixa.associate = models => {
      Faixa.belongsTo(models.Disco, { foreignKey: 'disco_id', as: 'disco' });
    };
  
    return Faixa;
  };
  