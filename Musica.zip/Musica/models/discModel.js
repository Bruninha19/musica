module.exports = (sequelize, DataTypes) => {
    const Disco = sequelize.define('Disco', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      titulo: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      ano_lancamento: {
        type: DataTypes.INTEGER,
      },
      capa: {
        type: DataTypes.STRING(255),
      },
      artista_id: {
        type: DataTypes.INTEGER,
        references: {
          model: 'artistas',
          key: 'id',
        },
      },
    }, {
      tableName: 'discos', // Nome da tabela no banco de dados
      timestamps: false,
      freezeTableName: true,
    });
  
    Disco.associate = models => {
      Disco.belongsTo(models.Artista, { foreignKey: 'artista_id', as: 'artista' });
      Disco.hasMany(models.Faixa, { foreignKey: 'disco_id', as: 'faixas' });
    };
  
    return Disco;
  };
  