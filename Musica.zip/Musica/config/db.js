const { Client } = require('pg');

const client = new Client({
    user: 'seu_usuario',
    host: 'localhost',
    database: 'catalogo_musical',
    password: 'sua_senha',
    port: 5432,
});

client.connect()
    .then(() => console.log('Conectado ao banco de dados'))
    .catch(err => console.error('Erro ao conectar', err));

module.exports = client;