const { Artist, Disc, Genre } = require('../models');

const artistController = {
  async create(req, res) {
    try {
      const { name, genreId } = req.body;
      const artist = await Artist.create({ name, genreId });
      res.status(201).json(artist);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },

  async list(req, res) {
    try {
      const artists = await Artist.findAll({ include: [Genre, Disc] });
      res.status(200).json(artists);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },

  async update(req, res) {
    try {
      const { id } = req.params;
      const { name, genreId } = req.body;
      const artist = await Artist.update({ name, genreId }, { where: { id } });
      res.status(200).json(artist);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },

  async delete(req, res) {
    try {
      const { id } = req.params;
      await Artist.destroy({ where: { id } });
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },
};

module.exports = artistController;
