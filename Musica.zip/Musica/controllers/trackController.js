const Track = require('../models/trackModel');

const TrackController = {
    criar: async (req, res) => {
        const { titulo, disco_id } = req.body;
        try {
            const track = await Track.criar(titulo, disco_id);
            res.status(201).json(track);
        } catch (error) {
            console.error('Erro ao criar faixa:', error);
            res.status(500).json({ error: 'Erro ao criar faixa' });
        }
    },
    listar: async (req, res) => {
        try {
            const tracks = await Track.listar();
            res.json(tracks);
        } catch (error) {
            console.error('Erro ao listar faixas:', error);
            res.status(500).json({ error: 'Erro ao listar faixas' });
        }
    },
    buscar: async (req, res) => {
        const { titulo } = req.query;
        try {
            const tracks = await Track.buscar(titulo);
            res.json(tracks);
        } catch (error) {
            console.error('Erro ao buscar faixa:', error);
            res.status(500).json({ error: 'Erro ao buscar faixa' });
        }
    },
    editar: async (req, res) => {
        const { id } = req.params;
        const { titulo, disco_id } = req.body;
        try {
            const track = await Track.editar(id, titulo, disco_id);
            res.json(track);
        } catch (error) {
            console.error('Erro ao editar faixa:', error);
            res.status(500).json({ error: 'Erro ao editar faixa' });
        }
    },
    remover: async (req, res) => {
        const { id } = req.params;
        try {
            await Track.remover(id);
            res.sendStatus(204);
        } catch (error) {
            console.error('Erro ao remover faixa:', error);
            res.status(500).json({ error: 'Erro ao remover faixa' });
        }
    }
};

module.exports = TrackController;