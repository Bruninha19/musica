const Genero = require('../models/genreModel');

const GeneroController = {
    criar: async (req, res) => {
        const { nome } = req.body;
        const genero = await Genero.criar(nome);
        res.json(genero);
    },
    listar: async (req, res) => {
        const generos = await Genero.listar();
        res.json(generos);
    },
    buscar: async (req, res) => {
        const { nome } = req.query;
        const generos = await Genero.buscar(nome);
        res.json(generos);
    },
    editar: async (req, res) => {
        const { id } = req.params;
        const { nome } = req.body;
        const genero = await Genero.editar(id, nome);
        res.json(genero);
    },
    remover: async (req, res) => {
        const { id } = req.params;
        await Genero.remover(id);
        res.sendStatus(204);
    }
};

module.exports = GeneroController;