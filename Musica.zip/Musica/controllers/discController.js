const { Disc, Artist, Genre, Track } = require('../models');

const discController = {
  async create(req, res) {
    try {
      const { title, releaseYear, coverImage, genreIds, artistId } = req.body;
      const disc = await Disc.create({ title, releaseYear, coverImage, artistId });
      await disc.setGenres(genreIds);
      res.status(201).json(disc);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },

  async list(req, res) {
    try {
      const discs = await Disc.findAll({ include: [Artist, Genre, Track] });
      res.status(200).json(discs);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },

  async update(req, res) {
    try {
      const { id } = req.params;
      const { title, releaseYear, coverImage, genreIds } = req.body;
      const disc = await Disc.update({ title, releaseYear, coverImage }, { where: { id } });
      const updatedDisc = await Disc.findByPk(id);
      await updatedDisc.setGenres(genreIds);
      res.status(200).json(updatedDisc);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },

  async delete(req, res) {
    try {
      const { id } = req.params;
      await Disc.destroy({ where: { id } });
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  },
};

module.exports = discController;
