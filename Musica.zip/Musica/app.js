const express = require('express');
const db = require('./config/db'); // Importa a conexão com o banco
const genreRoutes = require('./routes/genreRoutes');
const artistRoutes = require('./routes/artistRoutes');
const discRoutes = require('./routes/discRoutes');
const trackRoutes = require('./routes/trackRoutes');

const app = express();

// Middlewares
app.use(express.json()); // Permite parse de JSON no corpo das requisições

// Rotas
app.use('/generos', genreRoutes);
app.use('/artistas', artistRoutes);
app.use('/discos', discRoutes);
app.use('/faixas', trackRoutes);

// Teste de conexão ao banco
db.query('SELECT NOW()') // Teste simples para verificar a conexão
    .then(res => console.log('Banco de dados conectado, hora atual:', res.rows[0]))
    .catch(error => console.error('Erro ao conectar ao banco de dados:', error));

// Configuração do servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

module.exports = app;