const express = require('express');
const router = express.Router();
const trackController = require('../controllers/trackController');

// Rotas para Faixas
router.get('/', trackController.getAllFaixas); // Listar todas as faixas
router.get('/:id', trackController.getFaixaById); // Obter faixa por ID
router.post('/', trackController.createFaixa); // Criar nova faixa
router.put('/:id', trackController.updateFaixa); // Atualizar faixa por ID
router.delete('/:id', trackController.deleteFaixa); // Excluir faixa por ID

module.exports = router;
