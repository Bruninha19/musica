const express = require('express');
const router = express.Router();
const artistController = require('../controllers/artistController');

// Rotas para Artistas
router.get('/', artistController.getAllArtistas); // Listar todos os artistas
router.get('/:id', artistController.getArtistaById); // Obter artista por ID
router.post('/', artistController.createArtista); // Criar novo artista
router.put('/:id', artistController.updateArtista); // Atualizar artista por ID
router.delete('/:id', artistController.deleteArtista); // Excluir artista por ID

module.exports = router;
