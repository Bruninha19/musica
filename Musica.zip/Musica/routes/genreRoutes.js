const express = require('express');
const router = express.Router();
const genreController = require('../controllers/genreController');

// Rotas para Gêneros
router.get('/', genreController.getAllGeneros); // Listar todos os gêneros
router.get('/:id', genreController.getGeneroById); // Obter gênero por ID
router.post('/', genreController.createGenero); // Criar novo gênero
router.put('/:id', genreController.updateGenero); // Atualizar gênero por ID
router.delete('/:id', genreController.deleteGenero); // Excluir gênero por ID

module.exports = router;
