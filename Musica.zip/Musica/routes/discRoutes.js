const express = require('express');
const router = express.Router();
const discController = require('../controllers/discController');

// Rotas para Discos
router.get('/', discController.getAllDiscos); // Listar todos os discos
router.get('/:id', discController.getDiscoById); // Obter disco por ID
router.post('/', discController.createDisco); // Criar novo disco
router.put('/:id', discController.updateDisco); // Atualizar disco por ID
router.delete('/:id', discController.deleteDisco); // Excluir disco por ID

module.exports = router;
